import pandas as pd
import joblib
from sklearn.preprocessing import LabelEncoder
import warnings


def predict_grade(subject, input_data):
    """
    Predict final grade using the saved model for a specific subject

    Parameters:
    - subject: 'Easy', 'Medium', or 'Hard'
    - input_data: Dictionary containing all required features
    """

    # Suppress scikit-learn version warnings
    warnings.filterwarnings("ignore", category=UserWarning)

    try:
        # Load the saved model with allow_pickle=True to handle version differences
        model_data = joblib.load(f'subject_models/{subject}_best_model.pkl',)
        print(f"\nLoaded {subject} model successfully")
    except FileNotFoundError:
        print(f"\nError: Model for {subject} not found. Please train the model first.")
        return None

    # Extract components from saved model
    model = model_data['model']
    label_encoders = model_data['label_encoders']
    feature_groups = model_data['feature_groups']

    # Convert input data to DataFrame
    input_df = pd.DataFrame([input_data])

    # Preprocess the input data
    all_features = feature_groups['high'] + feature_groups['medium'] + feature_groups['low']

    # Ensure we only keep features used in training
    input_df = input_df[all_features]

    # Encode categorical variables with proper unseen label handling
    for col, le in label_encoders.items():
        if col in input_df.columns:
            # Convert to string and handle unseen labels
            input_df[col] = input_df[col].astype(str)
            # Replace unseen categories with the most frequent one
            most_frequent = le.classes_[0]  # Default to first category if no mode exists
            input_df[col] = input_df[col].apply(lambda x: x if x in le.classes_ else most_frequent)
            input_df[col] = le.transform(input_df[col])

    # Make prediction
    try:
        predicted_grade = model.predict(input_df)[0]
        accuracy = model_data['performance']['Accuracy (%)'].max()

        print(f"\nPredicted Final Grade for {subject}: {predicted_grade:.2f}")
        print(f"Model Accuracy: {accuracy:.2f}%")
        print("\nUsed Features:")
        print(", ".join(all_features))

        return predicted_grade
    except Exception as e:
        print(f"\nPrediction failed: {str(e)}")
        return None


# Example usage with better input handling
if __name__ == "__main__":
    print("=== Grade Prediction System ===")
    print("Available Subjects: Easy, Medium, Hard")

    # Sample input data structure
    sample_data = {
        'Midterm_Marks': 75,
        'quiz1': 85,
        'quiz2': 80,
        'Assignment1': 90,
        'Assignment2': 85,
        'Hours_Studied': 15,
        'Attendance': 95,
        'Sleep_Hours': 7,
        'Gender': 'Male',
        'Peer_Influence': 'High',
        'Motivation_Level': 'Medium',
        'Teacher_Quality': 'Good',
        'Extracurricular_Activities': 'Yes',
        'Physical_Activity': 'Moderate'
    }

    print("\nSample input structure:")
    for k, v in sample_data.items():
        print(f"{k}: {v}")

    # Get user input
    subject = input("\nEnter subject to predict (Easy/Medium/Hard): ").strip().capitalize()

    if subject not in ['Easy', 'Medium', 'Hard']:
        print("Invalid subject entered. Please choose from Easy, Medium, or Hard.")
    else:
        # Get actual values from user
        input_data = {}
        print("\nEnter values for each feature (press Enter to use sample values):")
        for feature in sample_data.keys():
            value = input(f"{feature} (default={sample_data[feature]}): ").strip()
            input_data[feature] = float(value) if value and value.replace('.', '', 1).isdigit() else (
                value if value else sample_data[feature])

        # Predict grade
        prediction = predict_grade(subject, input_data)

        # Display grade classification if prediction succeeded
        if prediction is not None:
            print("\nGrade Classification:")
            if prediction >= 90:
                print(f"{prediction:.2f} → A+")
            elif prediction >= 80:
                print(f"{prediction:.2f} → A")
            elif prediction >= 70:
                print(f"{prediction:.2f} → B")
            elif prediction >= 60:
                print(f"{prediction:.2f} → C")
            elif prediction >= 50:
                print(f"{prediction:.2f} → D")
            else:
                print(f"{prediction:.2f} → F")